//
//  ViewController.h
//  Chap11_Physical_simulation
//
//  Created by Joonwon Lee on 3/27/17.
//  Copyright © 2017 joonwon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController <UIAccelerometerDelegate>


@end

