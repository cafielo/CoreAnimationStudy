//
//  ViewController.swift
//  UIDynamics
//
//  Created by Joonwon Lee on 3/27/17.
//  Copyright © 2017 joonwon. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    var blueBoxView: UIView?
    var redBoxView: UIView?
    var animator: UIDynamicAnimator?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var frameRect = CGRect(x: 10, y: 20, width: 80, height: 80)
        blueBoxView = UIView(frame: frameRect)
        blueBoxView?.backgroundColor = UIColor.blue
        
        frameRect = CGRect(x: 150, y: 20, width: 60, height: 60)
        redBoxView = UIView(frame: frameRect)
        redBoxView?.backgroundColor = UIColor.red
        
        view.addSubview(blueBoxView!)
        view.addSubview(redBoxView!)
        
        animator = UIDynamicAnimator(referenceView: view)
        
        let gravity = UIGravityBehavior(items: [blueBoxView!, redBoxView!])
        let vector = CGVector(dx: 0.0, dy: 1.0)
        gravity.gravityDirection = vector
        
        let collision = UICollisionBehavior(items: [blueBoxView!, redBoxView!])
        collision.translatesReferenceBoundsIntoBoundary = true
        
        let behavior = UIDynamicItemBehavior(items: [blueBoxView!])
        behavior.elasticity = 0.5
        
        animator?.addBehavior(collision)
        animator?.addBehavior(gravity)
        animator?.addBehavior(behavior)
    }

    
}
